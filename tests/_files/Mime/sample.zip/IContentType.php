<?php
namespace Hurah\Types\Type\Mime;

/**
 *
 */

/**
 *
 */
interface IContentType
{
	/**
	 * @return string
	 */
	public function getContentTypes():array;
}
