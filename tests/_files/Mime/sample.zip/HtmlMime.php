<?php

namespace Hurah\Types\Type\Mime;

/**
 * Class doc comment
 */
/**
 * Generic type: Markup
 */
class HtmlMime extends AbstractMime implements Mime, IContentType
{

	/**
	 * @return string
	 */
	final public function getCode(): string
    {
        return 'html';
    }

	public function getContentTypes(): array
	{
		return [
		  'text/html'
		];
	}
}
