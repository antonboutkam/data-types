<?php

namespace Hurah\Types\Type\Mime;

/**
 * Class doc comment
 */
/**
 * Generic type: Unknown
 */
class JavascriptMime extends AbstractMime implements Mime, IContentType
{
	/**
	 * @return string
	 */
	final public function getCode(): string
	{
		return 'js';
	}

	/**
	 * @return array
	 */
	final public function getContentTypes(): array
    {
        return ['application/javascript'];
    }


}
