<?php

namespace Hurah\Types\Type\Mime;

/**
 * Class doc comment
 */
/**
 * Generic type: SourceCode
 */
class JsonMime extends AbstractMime implements Mime, IContentType
{
	/**
	 * @return string
	 */
	final public function getCode(): string
	{
		return 'json';
	}

	/**
	 * @return string
	 */
	final public function getContentTypes(): array
    {
        return ['application/json'];
    }

}
