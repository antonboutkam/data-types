<?php

namespace Hurah\Types\Type\Mime;

/**
 * Class doc comment
 */
/**
 * Generic type: Image
 */
class JpgMime extends AbstractMime implements Mime, IContentType
{

	/**
	 * @return string
	 */
	final public function getCode(): string
	{
		return 'jpg';
	}

	/**
	 * @return string
	 */
	final public function getContentTypes(): array
	{
		return ['image/jpeg'];
	}
}
